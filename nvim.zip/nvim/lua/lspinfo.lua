local lsp_zero = require('lsp-zero')
local lspconfig = require('lspconfig')
local mason = require('mason')
local masonlspconfig = require('mason-lspconfig')
local cmp = require('cmp')
local cmp_action = require('lsp-zero').cmp_action()
local cmp_format = require('lsp-zero').cmp_format({details = true})

lsp_zero.on_attach(function(client, bufnr)
  lsp_zero.default_keymaps({buffer = bufnr})
end)

require('mason').setup({})
require('mason-lspconfig').setup({
  -- Replace the language servers listed here
  -- with the ones you want to install
  ensure_installed = {},
  handlers = {
    lsp_zero.default_setup,
  }
})

require('luasnip.loaders.from_vscode').lazy_load()
require('luasnip').filetype_extend("typescript", {"javascript"})

local lsp_configurations = require('lspconfig.configs')

local server_config = {
    ["doesItThrow"] = {
      throwStatementSeverity = "Hint",
      functionThrowSeverity = "Hint",
      callToThrowSeverity = "Hint",
      callToImportedThrowSeverity = "Error",
      includeTryStatementThrows = true,
      maxNumberOfProblems = 10000
    }
}

-- Setup doesItThrow
if not lsp_configurations.does_it_throw_server then
    lsp_configurations.does_it_throw_server = {
        default_config = {
            cmd = {"does-it-throw-lsp", "--stdio"},
            filetypes = {"typescript", "javascript"},
            root_dir = function(fname)
                return vim.fn.getcwd()
            end
        }
    }
end

require'lspconfig'.does_it_throw_server.setup {
    on_init = function(client)
        client.config.settings = server_config
    end,
		-- important to set this up so that the server can find your desired settings
    handlers = {
        ["workspace/configuration"] = function(_, params, _, _)
            local configurations = {}
            for _, item in ipairs(params.items) do
                if item.section then
                    table.insert(configurations, server_config[item.section])
                end
            end
            return configurations
        end
    }
}

cmp.setup({
  sources = {
    {name = 'nvim_lsp'},
    {name = 'luasnip'},
  },
  mapping = {
    ['<CR>'] = cmp.mapping.confirm({select = false}),
    ['<C-e>'] = cmp.mapping.abort(),
    ['<S-Tab>'] = cmp.mapping.select_prev_item({behavior = 'select'}),
    ['<Tab>'] = cmp.mapping.select_next_item({behavior = 'select'}),
  },
  snippet = {
    expand = function(args)
      require('luasnip').lsp_expand(args.body)
    end,
  },

  formatting = cmp_format,
})
