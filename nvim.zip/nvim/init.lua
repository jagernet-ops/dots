require('colors')
require('plugins');
require('remap');
require('lspinfo')
vim.opt.relativenumber = true;
vim.opt.number = true;
vim.opt.expandtab = true;
vim.opt.tabstop = 2;
vim.opt.shiftwidth = 2;
vim.opt.autoindent = true;
require('gitblame').setup {
     --Note how the `gitblame_` prefix is omitted in `setup`
    enabled = false,
}
require("autoclose").setup()
